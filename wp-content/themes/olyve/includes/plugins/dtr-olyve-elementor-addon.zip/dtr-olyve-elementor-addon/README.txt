=== Olyve Elementor Addons ===
Contributors: tansh
Tags: Elementor, Addon
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Addons for premium elemetor plugin.

== Description ==
Addons for premium elemetor plugin.

== Changelog ==

= 1.0.5 =
- Updated: Path to resize php file
- New: Equal height to recent post carousel items

= 1.0.4 =
– Fix for heading with gradient for selected safari browser

= 1.0.3 =
- Updated: Recent Posts Carousel

= 1.0.2 =
- Fix: Notice: Function _load_textdomain_just_in_time


= 1.0.0 =
* Initial release.
